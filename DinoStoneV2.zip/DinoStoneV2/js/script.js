var interval;

function isDinoHit() {
    var stone = $("#stone");
    const stonex = stone.offset().left;
    const stoney = stone.offset().top;

    //Your code for checking Dino's (looping) positions and stone collision goes here.
	var stoneHit = document.getElementById('stone').getBoundingClientRect();
	var dinoHit = document.getElementsByClassName('movingDino')[0].getBoundingClientRect();
	var overlap = !(stoneHit.right < dinoHit.left || 
                stoneHit.left > dinoHit.right || 
                stoneHit.bottom < dinoHit.top || 
                stoneHit.top > dinoHit.bottom)
		if(overlap)
		{
		alert();
		}
    $(".image-wrapper").remove(); // Removing the stone after finding distance.
}

$(document).ready(function() {
    $(".top-container").click(function(e) {
        if ($(".image-wrapper").length == 0) {
            var div = $('<div class="image-wrapper">')
                .css({
                    "left": e.pageX + 'px',
                    "top": e.pageY + 'px'
                })
                .append($('<img src="images/stone.png" alt="myimage" id="stone"/>'))
                .appendTo(document.body)
                .animate({
                    top: "100vh"
                }, 1500)
                .promise()
                .done(function() {
                    isDinoHit();
                })
        }
    })

    var i = 0;
    interval = setInterval(function() {
        if (i == 5)
            clearInterval(interval)
        $(".walkingDino").clone().attr('class', 'movingDino').appendTo(".bottom-container");
        ele = $(".movingDino").eq(i)
        ele.animate({
            left: '-150px'
        }, 13000);
        i++;
    }, 2000)
})