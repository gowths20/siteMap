import React, { Component } from 'react';
import ReactDOM from 'react-dom';
//import logo from './logo.svg';
import './App.css';
import data from './sample.json';
class App extends Component {
  constructor(props)
  {
   super()
   // const hTable = new HashTable(10);
    //console.log(hTable);
    this.state = {
      searched:false
    }
    this.find = this.search.bind(this);
    this.sort = this.filter.bind(this);
    this.filterData = data.filter.filterOptions
  }
  filter(event)
  {
    var val = event.target.value;
     console.log(val);   
     var a = data.details.sort(function(obj1, obj2) {
        return obj2.employeeAge - obj1.employeeAge;
      });
      console.log(a)
      this.forceUpdate();
  }
  search()
  {
   //console.log(ReactDOM.findDOMNode(this.refs.searchBox))
   //this.searchVal = ReactDOM.findDOMNode(this.refs.searchBox).value
   data.details.forEach(function(value,index)
   {
     if(value.employeeName.toLowerCase() === ReactDOM.findDOMNode(this.refs.searchBox).value.toLowerCase() || value.employeeNo === parseInt(ReactDOM.findDOMNode(this.refs.searchBox).value))
     {
       this.temp = [];
       this.temp.push(value)
       this.setState(
       {
         searched:true
       }
       )
       console.log(this.state.searched)
     }
   },this);
  }
  render() {
    return (
      <div className="App">
        <div className="table">
            <table border='1'>
            <tbody>
                <tr><th>Employee Number</th><th>Employee Name</th><th>Employee Age</th><th>Employee Salary</th></tr>
                {data.details.map((value, i) =><tr key={i+"a"}><td>{value.employeeNo}</td><td>{value.employeeName}</td><td>{value.employeeAge}</td><td>{value.employeeSalary}</td></tr>)}
                </tbody>
            </table>
          </div>
          <div className="filterSection">
              {this.filterData.map((values,i)=> <div key={i+""} className="checkbox"><label><input type="radio" name="filter" onChange = {this.sort} value={values.value} />{values.value}</label></div>)}
          </div>
          <div className="searchBar">
            <input type='text' ref='searchBox' />
            <button onClick ={this.find}>search</button>
          </div>
           <div className="result">
                {this.state.searched?(<table border='1'><tbody><tr><th>Employee Number</th><th>Employee Name</th><th>Employee Age</th><th>Employee Salary</th></tr>{this.temp.map((value, i) =><tr key={i+"b"}><td>{value.employeeNo}</td><td>{value.employeeName}</td><td>{value.employeeAge}</td><td>{value.employeeSalary}</td></tr>)}</tbody></table>):null}
          </div>
      </div>
    );
  }
}

export default App;
